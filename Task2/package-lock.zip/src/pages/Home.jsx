const Home = () => {
  return (
    <div className="page">
      <h1>Welcome to ShopEase</h1>
      <p>Your one-stop shop for everything!</p>
    </div>
  );
};

export default Home;
