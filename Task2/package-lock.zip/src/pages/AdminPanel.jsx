const AdminPanel = () => {
  return (
    <div className="page">
      <h2>Admin Panel</h2>
      <p>Manage your inventory and orders here.</p>
    </div>
  );
};

export default AdminPanel;
