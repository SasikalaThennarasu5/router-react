import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './contexts/CartContext';
import Products from './pages/Products';
import CartSidebar from './components/CartSidebar';
import Navbar from './components/Navbar';

function App() {
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <CartProvider>
      <Router>
        <Navbar onCartClick={() => setCartOpen(true)} />
        <CartSidebar visible={cartOpen} onClose={() => setCartOpen(false)} />

        <Routes>
          <Route path="/products" element={<Products />} />
          {/* Add more routes as needed */}
        </Routes>
      </Router>
    </CartProvider>
  );
}

export default App;
