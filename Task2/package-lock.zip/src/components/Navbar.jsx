import React from 'react';

const Navbar = ({ onCartClick }) => {
  return (
    <nav>
      <h2>My Shop</h2>
      <button onClick={onCartClick}>🛒 Cart</button>
    </nav>
  );
};

export default Navbar;
